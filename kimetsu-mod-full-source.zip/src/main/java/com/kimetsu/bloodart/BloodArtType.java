package com.kimetsu.bloodart;

public enum BloodArtType {
    MUZAN("Muzan Kibutsuji", "Roi thịt và đòn đánh diện rộng", true),
    KOKUSHIBO("Kokushibo", "Trảm kích Mặt Trăng", true),
    DOMA("Doma", "Băng và sương giá", true),
    AKAZA("Akaza", "La Châm và đòn xung kích", true),
    HANTENGU("Hantengu", "Sấm sét và mộc long", true),
    GYOKKO("Gyokko", "Bình cá và độc", true),
    GYUTARO("Gyutaro", "Huyết liêm độc", true),
    DAKI("Daki", "Đai lụa trảm kích", true),
    NAKIME("Nakime", "Dịch chuyển không gian", true),
    KAIGAKU("Kaigaku", "Hắc lôi", true),
    ENMU("Enmu", "Ảo giác giấc mơ", true),
    RUI("Rui", "Tơ nhện", true),
    NEZUKO("Nezuko", "Bộc huyết diễm", true),
    SUSAMARU("Susamaru", "Temari oanh kích", true),
    YAHABA("Yahaba", "Đổi hướng quỹ đạo", true),
    KYOGAI("Kyogai", "Trống xoay", true),
    GENERIC_DEMON("Quỷ thường", "Năng lực do mod sáng tạo", false);

    private final String owner;
    private final String skillName;
    private final boolean canon;

    BloodArtType(String owner, String skillName, boolean canon) {
        this.owner = owner;
        this.skillName = skillName;
        this.canon = canon;
    }

    public String getOwner() { return owner; }
    public String getSkillName() { return skillName; }
    public boolean isCanon() { return canon; }
}
