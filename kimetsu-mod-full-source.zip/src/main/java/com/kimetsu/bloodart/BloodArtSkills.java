package com.kimetsu.bloodart;

import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.effect.StatusEffect;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.particle.ParticleTypes;
import net.minecraft.sound.SoundCategory;
import net.minecraft.sound.SoundEvents;
import net.minecraft.util.math.Box;
import net.minecraft.registry.entry.RegistryEntry;
import net.minecraft.world.World;

import java.util.List;

public final class BloodArtSkills {
    private BloodArtSkills() {}

    public static void useBloodArt(PlayerEntity player, World world, String key) {
        double x = player.getX(), y = player.getY(), z = player.getZ();
        String k = key.toLowerCase();
        int cooldown = 60;
        double radius = 4.0;
        float damage = 12.0f;
        RegistryEntry<StatusEffect> effect = StatusEffects.SLOWNESS;
        int duration = 80;
        int amplifier = 1;
        var particle = ParticleTypes.SOUL_FIRE_FLAME;
        var sound = SoundEvents.ENTITY_PLAYER_ATTACK_SWEEP;
        float pitch = 1.0f;

        switch (k) {
            case "muzan" -> { cooldown = 100; radius = 7.0; damage = 20; effect = StatusEffects.WITHER; duration = 100; amplifier = 1; particle = ParticleTypes.SOUL_FIRE_FLAME; sound = SoundEvents.ENTITY_WITHER_SPAWN; pitch = 0.7f; }
            case "kokushibo" -> { cooldown = 85; radius = 6.0; damage = 18; effect = StatusEffects.WEAKNESS; duration = 80; amplifier = 1; particle = ParticleTypes.CRIT; sound = SoundEvents.ENTITY_PLAYER_ATTACK_SWEEP; pitch = 0.7f; }
            case "doma" -> { cooldown = 80; radius = 6.0; damage = 16; effect = StatusEffects.SLOWNESS; duration = 140; amplifier = 2; particle = ParticleTypes.SNOWFLAKE; sound = SoundEvents.BLOCK_GLASS_BREAK; pitch = 1.4f; }
            case "akaza" -> { cooldown = 60; radius = 4.0; damage = 18; effect = StatusEffects.WEAKNESS; duration = 80; amplifier = 1; particle = ParticleTypes.CRIT; sound = SoundEvents.ENTITY_GENERIC_EXPLODE; pitch = 1.5f; }
            case "hantengu" -> { cooldown = 90; radius = 5.5; damage = 16; effect = StatusEffects.SLOWNESS; duration = 60; amplifier = 1; particle = ParticleTypes.ELECTRIC_SPARK; sound = SoundEvents.ENTITY_LIGHTNING_BOLT_THUNDER; }
            case "gyokko" -> { cooldown = 75; radius = 4.5; damage = 14; effect = StatusEffects.POISON; duration = 100; amplifier = 0; particle = ParticleTypes.BUBBLE_POP; sound = SoundEvents.ENTITY_FISH_SWIM; }
            case "gyutaro" -> { cooldown = 65; radius = 4.5; damage = 15; effect = StatusEffects.POISON; duration = 160; amplifier = 1; particle = ParticleTypes.DAMAGE_INDICATOR; sound = SoundEvents.ENTITY_SPIDER_DEATH; pitch = 0.8f; }
            case "daki" -> { cooldown = 55; radius = 5.0; damage = 13; effect = StatusEffects.SLOWNESS; duration = 40; amplifier = 1; particle = ParticleTypes.SWEEP_ATTACK; }
            case "nakime" -> {
                player.getItemCooldownManager().set(player.getMainHandStack().getItem(), 110);
                player.teleport(x + (Math.random() - 0.5) * 12, y + 1, z + (Math.random() - 0.5) * 12);
                world.playSound(null, x, y, z, SoundEvents.BLOCK_NOTE_BLOCK_HARP, SoundCategory.PLAYERS, 1.5f, 0.6f);
                return;
            }
            case "kaigaku" -> { cooldown = 50; radius = 3.5; damage = 16; effect = StatusEffects.WITHER; duration = 40; amplifier = 0; particle = ParticleTypes.ELECTRIC_SPARK; sound = SoundEvents.ENTITY_LIGHTNING_BOLT_IMPACT; pitch = 1.5f; }
            case "enmu" -> { cooldown = 80; radius = 6.0; damage = 8; effect = StatusEffects.BLINDNESS; duration = 100; amplifier = 0; particle = ParticleTypes.PORTAL; sound = SoundEvents.ENTITY_ILLUSIONER_CAST_SPELL; pitch = 0.8f; }
            case "rui" -> { cooldown = 50; radius = 4.0; damage = 13; effect = StatusEffects.SLOWNESS; duration = 80; amplifier = 1; particle = ParticleTypes.WHITE_ASH; sound = SoundEvents.ENTITY_SHEEP_SHEAR; pitch = 1.5f; }
            case "nezuko" -> { cooldown = 60; radius = 4.5; damage = 15; effect = null; duration = 0; amplifier = 0; particle = ParticleTypes.FLAME; sound = SoundEvents.ITEM_FIRECHARGE_USE; pitch = 1.2f; }
            case "susamaru" -> { cooldown = 45; radius = 3.5; damage = 12; effect = null; duration = 0; amplifier = 0; particle = ParticleTypes.CRIT; sound = SoundEvents.ENTITY_WITCH_THROW; }
            case "yahaba" -> { cooldown = 40; radius = 4.0; damage = 10; effect = null; duration = 0; amplifier = 0; particle = ParticleTypes.POOF; sound = SoundEvents.ENTITY_ARROW_SHOOT; pitch = 1.5f; }
            case "kyogai" -> { cooldown = 50; radius = 4.5; damage = 11; effect = StatusEffects.NAUSEA; duration = 80; amplifier = 0; particle = ParticleTypes.NOTE; sound = SoundEvents.BLOCK_NOTE_BLOCK_BASEDRUM; pitch = 0.8f; }
            default -> { cooldown = 60; radius = 3.0; damage = 9; effect = StatusEffects.HUNGER; duration = 100; amplifier = 0; particle = ParticleTypes.SQUID_INK; sound = SoundEvents.ENTITY_ZOMBIE_ATTACK_WOODEN_DOOR; pitch = 0.8f; }
        }

        player.getItemCooldownManager().set(player.getMainHandStack().getItem(), cooldown);
        world.playSound(null, x, y, z, sound, SoundCategory.PLAYERS, 1.0f, pitch);
        for (int i = 0; i < 36; i++) {
            double px = x + (Math.random() - 0.5) * radius * 2;
            double pz = z + (Math.random() - 0.5) * radius * 2;
            world.addParticle(particle, px, y + 0.8 + Math.random() * 1.5, pz, 0, 0.08, 0);
        }

        Box box = player.getBoundingBox().expand(radius);
        List<LivingEntity> targets = world.getNonSpectatingEntities(LivingEntity.class, box);
        for (LivingEntity target : targets) {
            if (target == player) continue;
            target.damage(world.getDamageSources().playerAttack(player), damage);
            if (k.equals("nezuko")) target.setOnFireFor(6);
            if (effect != null) target.addStatusEffect(new StatusEffectInstance(effect, duration, amplifier));
        }
    }
}
