package com.kimetsu;

import com.kimetsu.item.ModItems;
import net.fabricmc.api.ModInitializer;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class KimetsuMod implements ModInitializer {
    public static final String MOD_ID = "kimetsu";
    public static final Logger LOGGER = LoggerFactory.getLogger(MOD_ID);

    @Override
    public void onInitialize() {
        ModItems.registerModItems();
        LOGGER.info("Kimetsu no Yaiba loaded: 14 breathing swords and Blood Demon Art items registered.");
    }
}
