package com.kimetsu.breathing;

import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.particle.ParticleTypes;
import net.minecraft.sound.SoundCategory;
import net.minecraft.sound.SoundEvents;
import net.minecraft.util.math.Box;
import net.minecraft.world.World;

import java.util.List;

public final class BreathingSkills {
    private BreathingSkills() {}

    public static void executeSkill(PlayerEntity player, World world, String style) {
        double radius = 4.0;
        float damage = 12.0f;
        int cooldown = 45;
        var particle = ParticleTypes.SPLASH;
        var sound = SoundEvents.ENTITY_PLAYER_ATTACK_SWEEP;
        float pitch = 1.0f;

        switch (style.toLowerCase()) {
            case "sun" -> { radius = 5.5; damage = 18; cooldown = 75; particle = ParticleTypes.FLAME; pitch = 1.2f; }
            case "moon" -> { radius = 5.0; damage = 17; cooldown = 70; particle = ParticleTypes.CRIT; pitch = 0.7f; }
            case "water" -> { radius = 4.5; damage = 13; cooldown = 45; particle = ParticleTypes.SPLASH; }
            case "flame" -> { radius = 4.5; damage = 16; cooldown = 55; particle = ParticleTypes.FLAME; sound = SoundEvents.ITEM_FIRECHARGE_USE; }
            case "thunder" -> { radius = 3.5; damage = 17; cooldown = 60; particle = ParticleTypes.ELECTRIC_SPARK; sound = SoundEvents.ENTITY_LIGHTNING_BOLT_IMPACT; pitch = 1.5f; }
            case "wind" -> { radius = 5.0; damage = 14; cooldown = 50; particle = ParticleTypes.CLOUD; }
            case "stone" -> { radius = 4.0; damage = 16; cooldown = 65; particle = ParticleTypes.POOF; pitch = 0.7f; }
            case "mist" -> { radius = 4.5; damage = 12; cooldown = 50; particle = ParticleTypes.CAMPFIRE_COSY_SMOKE; }
            case "sound" -> { radius = 5.0; damage = 15; cooldown = 60; particle = ParticleTypes.NOTE; sound = SoundEvents.BLOCK_NOTE_BLOCK_BASEDRUM; pitch = 1.4f; }
            case "love" -> { radius = 4.5; damage = 14; cooldown = 50; particle = ParticleTypes.HEART; }
            case "serpent" -> { radius = 4.0; damage = 14; cooldown = 45; particle = ParticleTypes.SWEEP_ATTACK; }
            case "flower" -> { radius = 4.0; damage = 13; cooldown = 45; particle = ParticleTypes.CHERRY_LEAVES; }
            case "insect" -> { radius = 3.5; damage = 10; cooldown = 35; particle = ParticleTypes.WAX_ON; }
            case "beast" -> { radius = 4.5; damage = 15; cooldown = 50; particle = ParticleTypes.CRIT; }
            default -> { radius = 4.0; damage = 10; cooldown = 50; }
        }

        player.getItemCooldownManager().set(player.getMainHandStack().getItem(), cooldown);
        if (style.equalsIgnoreCase("thunder") || style.equalsIgnoreCase("beast")) {
            player.addVelocity(player.getRotationVector().x * 1.6, 0.15, player.getRotationVector().z * 1.6);
            player.velocityModified = true;
        }

        double x = player.getX(), y = player.getY(), z = player.getZ();
        world.playSound(null, x, y, z, sound, SoundCategory.PLAYERS, 1.0f, pitch);
        for (int i = 0; i < 32; i++) {
            double angle = Math.PI * 2.0 * i / 32.0;
            world.addParticle(particle, x + Math.cos(angle) * radius, y + 1.0, z + Math.sin(angle) * radius, 0, 0.06, 0);
        }

        Box box = player.getBoundingBox().expand(radius);
        List<LivingEntity> targets = world.getNonSpectatingEntities(LivingEntity.class, box);
        for (LivingEntity target : targets) {
            if (target == player) continue;
            target.damage(world.getDamageSources().playerAttack(player), damage);
            if (style.equalsIgnoreCase("insect")) {
                target.addStatusEffect(new StatusEffectInstance(StatusEffects.POISON, 80, 0));
            } else if (style.equalsIgnoreCase("mist")) {
                target.addStatusEffect(new StatusEffectInstance(StatusEffects.SLOWNESS, 40, 1));
            }
        }
    }
}
