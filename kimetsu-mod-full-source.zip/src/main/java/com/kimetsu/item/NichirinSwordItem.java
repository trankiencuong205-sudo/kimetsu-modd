package com.kimetsu.item;

import com.kimetsu.bloodart.BloodArtSkills;
import com.kimetsu.breathing.BreathingSkills;
import net.minecraft.item.ItemStack;
import net.minecraft.item.SwordItem;
import net.minecraft.item.ToolMaterial;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.util.Hand;
import net.minecraft.util.TypedActionResult;
import net.minecraft.world.World;

public class NichirinSwordItem extends SwordItem {
    private final String skillType;
    private final boolean bloodArt;

    public NichirinSwordItem(ToolMaterial material, Settings settings, String skillType, boolean bloodArt) {
        super(material, settings);
        this.skillType = skillType;
        this.bloodArt = bloodArt;
    }

    @Override
    public TypedActionResult<ItemStack> use(World world, PlayerEntity user, Hand hand) {
        ItemStack stack = user.getStackInHand(hand);
        if (!world.isClient) {
            if (bloodArt) {
                BloodArtSkills.useBloodArt(user, world, skillType);
            } else {
                BreathingSkills.executeSkill(user, world, skillType);
            }
        }
        return TypedActionResult.success(stack, world.isClient);
    }
}
