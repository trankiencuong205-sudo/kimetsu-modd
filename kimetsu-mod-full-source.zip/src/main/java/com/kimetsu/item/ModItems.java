package com.kimetsu.item;

import com.kimetsu.KimetsuMod;
import net.fabricmc.fabric.api.itemgroup.v1.ItemGroupEvents;
import net.minecraft.item.Item;
import net.minecraft.item.ItemGroups;
import net.minecraft.item.ToolMaterials;
import net.minecraft.registry.Registries;
import net.minecraft.registry.Registry;
import net.minecraft.util.Identifier;

import java.util.LinkedHashMap;
import java.util.Map;

public final class ModItems {
    private static final Map<String, Item> ALL_ITEMS = new LinkedHashMap<>();

    public static final Item NICHIRIN_SUN = register("nichirin_sun", "sun", false);
    public static final Item NICHIRIN_MOON = register("nichirin_moon", "moon", false);
    public static final Item NICHIRIN_WATER = register("nichirin_water", "water", false);
    public static final Item NICHIRIN_FLAME = register("nichirin_flame", "flame", false);
    public static final Item NICHIRIN_THUNDER = register("nichirin_thunder", "thunder", false);
    public static final Item NICHIRIN_WIND = register("nichirin_wind", "wind", false);
    public static final Item NICHIRIN_STONE = register("nichirin_stone", "stone", false);
    public static final Item NICHIRIN_MIST = register("nichirin_mist", "mist", false);
    public static final Item NICHIRIN_SOUND = register("nichirin_sound", "sound", false);
    public static final Item NICHIRIN_LOVE = register("nichirin_love", "love", false);
    public static final Item NICHIRIN_SERPENT = register("nichirin_serpent", "serpent", false);
    public static final Item NICHIRIN_FLOWER = register("nichirin_flower", "flower", false);
    public static final Item NICHIRIN_INSECT = register("nichirin_insect", "insect", false);
    public static final Item NICHIRIN_BEAST = register("nichirin_beast", "beast", false);

    public static final Item BLOOD_MUZAN = register("blood_muzan", "muzan", true);
    public static final Item BLOOD_KOKUSHIBO = register("blood_kokushibo", "kokushibo", true);
    public static final Item BLOOD_DOMA = register("blood_doma", "doma", true);
    public static final Item BLOOD_AKAZA = register("blood_akaza", "akaza", true);
    public static final Item BLOOD_HANTENGU = register("blood_hantengu", "hantengu", true);
    public static final Item BLOOD_GYOKKO = register("blood_gyokko", "gyokko", true);
    public static final Item BLOOD_GYUTARO = register("blood_gyutaro", "gyutaro", true);
    public static final Item BLOOD_DAKI = register("blood_daki", "daki", true);
    public static final Item BLOOD_NAKIME = register("blood_nakime", "nakime", true);
    public static final Item BLOOD_KAIGAKU = register("blood_kaigaku", "kaigaku", true);
    public static final Item BLOOD_ENMU = register("blood_enmu", "enmu", true);
    public static final Item BLOOD_RUI = register("blood_rui", "rui", true);
    public static final Item BLOOD_NEZUKO = register("blood_nezuko", "nezuko", true);
    public static final Item BLOOD_SUSAMARU = register("blood_susamaru", "susamaru", true);
    public static final Item BLOOD_YAHABA = register("blood_yahaba", "yahaba", true);
    public static final Item BLOOD_KYOGAI = register("blood_kyogai", "kyogai", true);
    public static final Item BLOOD_GENERIC = register("blood_generic", "generic", true);

    private ModItems() {}

    private static Item register(String name, String skillType, boolean bloodArt) {
        Item item = Registry.register(
                Registries.ITEM,
                Identifier.of(KimetsuMod.MOD_ID, name),
                new NichirinSwordItem(
                        ToolMaterials.NETHERITE,
                        new Item.Settings().maxCount(1).attributeModifiers(
                                NichirinSwordItem.createAttributeModifiers(ToolMaterials.NETHERITE, 8.0f, -2.4f)
                        ),
                        skillType,
                        bloodArt
                )
        );
        ALL_ITEMS.put(name, item);
        return item;
    }

    public static void registerModItems() {
        ItemGroupEvents.modifyEntriesEvent(ItemGroups.COMBAT).register(entries -> {
            for (Item item : ALL_ITEMS.values()) {
                entries.add(item);
            }
        });
    }
}
