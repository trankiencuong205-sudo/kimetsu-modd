# Kimetsu no Yaiba - Fabric 1.21.1

This is an expanded starter MVP assembled from the latest code the user provided. It includes 14 breathing-style swords and 17 Blood Demon Art items, with basic area attacks, particles, sounds, cooldowns, and selected status effects.

**Important:** This is not yet a complete anime-faithful mod. It does not yet include custom 3D character models, custom sword textures, demon NPCs/bosses, or a GUI. The provided code has been organized and some omissions fixed, but the project has not been built in this environment; the GitHub Actions run must confirm compilation.

## Build
Use Java 21 and Minecraft Java Edition 1.21.1 with Fabric. Push this project to a GitHub repository. The workflow at `.github/workflows/build.yml` builds it and uploads `build/libs/*.jar` as an artifact.

## Install
Install Fabric Loader for Minecraft 1.21.1 and matching Fabric API. Download the JAR artifact from GitHub Actions and place it in `.minecraft/mods`.
